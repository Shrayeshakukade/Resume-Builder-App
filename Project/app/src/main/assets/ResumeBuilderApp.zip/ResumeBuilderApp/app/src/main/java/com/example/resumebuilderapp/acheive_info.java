package com.example.resumebuilderapp;

public class acheive_info {
    private  String acheive1,acheive2;
    public acheive_info(){}

    public acheive_info(String acheive1, String acheive2) {
        this.acheive1 = acheive1;
        this.acheive2 = acheive2;
    }

    public String getAcheive1() {
        return acheive1;
    }

    public void setAcheive1(String acheive1) {
        this.acheive1 = acheive1;
    }

    public String getAcheive2() {
        return acheive2;
    }

    public void setAcheive2(String acheive2) {
        this.acheive2 = acheive2;
    }
}
