package com.example.resumebuilderapp;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintJob;
import android.print.PrintManager;
import android.view.View;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class Template7 extends AppCompatActivity {

    private DatabaseReference reff,reff1,reff2;
    private FirebaseAuth firebaseAuth;
    private FirebaseDatabase firebaseDatabase;
    private WebView webView;
    PrintDocumentAdapter adapter;
    private String nme,add1,add2,add3,eml,phno,skil1,skil2,skil3,com,from,role,to;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_template7);

        firebaseAuth=FirebaseAuth.getInstance();
        firebaseDatabase=FirebaseDatabase.getInstance();
        webView=(WebView)findViewById(R.id.webview);
        reff=FirebaseDatabase.getInstance().getReference(firebaseAuth.getUid()).child("basic_details");
        reff.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                nme=dataSnapshot.child("name").getValue().toString();
                add1=dataSnapshot.child("add1").getValue().toString();
                add2=dataSnapshot.child("add2").getValue().toString();
                add3=dataSnapshot.child("add3").getValue().toString();
                eml=dataSnapshot.child("email").getValue().toString();
                phno=dataSnapshot.child("mobno").getValue().toString();
                code();

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        reff1=FirebaseDatabase.getInstance().getReference(firebaseAuth.getUid()).child("Skill_info");
        reff1.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                skil1=dataSnapshot.child("skill1").getValue().toString();
                skil2=dataSnapshot.child("skill2").getValue().toString();
                skil3=dataSnapshot.child("skill3").getValue().toString();

                code();

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        reff2=FirebaseDatabase.getInstance().getReference(firebaseAuth.getUid()).child("experienceinfo");
        reff2.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                com=dataSnapshot.child("company").getValue().toString();
                from=dataSnapshot.child("from").getValue().toString();
                role=dataSnapshot.child("role").getValue().toString();
                to=dataSnapshot.child("to").getValue().toString();
                code();

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });



    }


    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    public void createpdf(View view){
        Context context=Template7.this;
        PrintManager printManager=(PrintManager)Template7.this.getSystemService(context.PRINT_SERVICE);
        PrintDocumentAdapter printDocumentAdapter=null;
        if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.KITKAT){
            adapter=webView.createPrintDocumentAdapter();
        }
        String Jobname=getString(R.string.app_name)+"Document";
        if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.KITKAT){
            PrintJob printJob=printManager.print(Jobname,adapter,new PrintAttributes.Builder().build());
        }
    }
    public void code()
    {
        String html="<!DOCTYPE html>\n" +
                "<html>\n" +
                "<head>\n" +
                "\t<title></title>\n" +
                "\n" +
                "<link rel=\"stylesheet\" type=\"text/css\" href=\"file:android_asset/Layout3.css\">\n" +
                "</head>\n" +
                "\n" +
                "<div class=\"wrapper clearfix\">\n" +
                "<div class=\"left\">\n" +
                "    \n" +
                "    <div class=\"name-hero\">\n" +
                "      \n" +
                "      <div class=\"me-img\"></div>\n" +
                "      \n" +
                "      <div class=\"name-text\">\n" +
                "        \n" +
                "        <h1 id = \"nme\">Name</h1>\n" +
                "        <p id = \"Add1\" id=\"add2\" id=\"add3\"><em> Add1</em>Add2<em>Add3</em></p>\n" +
                "        <p id = \"email\">email(abc@gmail.com)</p>\n" +
                "        <p id= \"phno\">phoneNo</p>\n" +
                "     \n" +
                "      </div>\n" +
                "   \n" +
                "    </div>\n" +
                "    \n" +
                "  </div>\n" +
                " <div class=\"right\">\n" +
                "    \n" +
                "\t\n" +
                "    <div class=\"inner\">\n" +
                "\t<section>\n" +
                "        <h1>Education</h1>\n" +
                "\t\t<ul class=\"skill-set\">\n" +
                "          <p id= \"Edu1\">Education1</p>\n" +
                "         </ul>\n" +
                "      </section>\n" +
                "      \n" +
                "      <section>\n" +
                "        <h1>Experience</h1>\n" +
                "        <p id=\"exp1\">Experience1</p>\n" +
                "\t<p id=\"exp2\">Experience2</p>\n" +
                "                 \n" +
                "\t </section>\n" +
                "      \n" +
                "<section>\n" +
                "        <h1>Project</h1>\n" +
                "        <p id=\"pro1\">Project title</p>\n" +
                "\t<p id=\"des1\">description</p>\n" +
                "\t<p id=\"dur1\">duration</p>\n" +
                "\n" +
                " \t<p id=\"pro2\">Project title</p>\n" +
                "\t<p id=\"des2\">description</p>\n" +
                "\t<p id=\"dur2\">duration</p>\n" +
                "                 \n" +
                "\t </section>\n" +
                "      \n" +
                "<section>\n" +
                "        <h1>Technical Skills</h1>\n" +
                "        <ul class=\"skill-set\">\n" +
                "          <li id=\"skill1\">Skill1</li>\n" +
                "          <li id=\"skill2\">Skill2</li>\n" +
                "          <li id=\"skill3\">Skill3</li>\n" +
                "         \n" +
                "        </ul>\n" +
                "      </section>\n" +
                "      <section>\n" +
                "        <h1>Personal Interests</h1>\n" +
                "        <ul class=\"skill-set\">\n" +
                "          <li id=\"int1\">Interest1</li>\n" +
                "          <li id=\"int2\">Interest2</li>\n" +
                "          <li id=\"int3\">Interest3</li>\n" +
                "         </ul>\n" +
                "      </section>\n" +
                "      <section>\n" +
                "        <h1>Achievements</h1>\n" +
                "\t\t<ul class=\"skill-set\">\n" +
                "          <li id=\"Ach1\">Achievement1</li>\n" +
                "          <li id=\"Ach2\">Achievement2</li>\n" +
                "         \n" +
                "        </ul>\n" +
                "      </section>\n" +
                "      <section>\n" +
                "        <div class=\"handmade\">\n" +
                "\t\t\n" +
                "          <p id=\"name\">handmade by <em>Name</em></p>\n" +
                "        </div>\n" +
                "      </section>\n" +
                "\t  \n" +
                "    </div>\n" +
                "    \n" +
                "  </div>\n" +
                "  \n" +
                "  \n" +
                "  \n" +
                "</div>\n" +
                "</body>\n" +
                "</html>\n ";
        webView.loadDataWithBaseURL(null,html,"text/html","utf-8",null);



    }



}
