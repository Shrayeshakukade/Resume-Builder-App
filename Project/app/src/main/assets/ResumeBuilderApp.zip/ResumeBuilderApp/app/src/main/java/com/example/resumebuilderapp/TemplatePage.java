package com.example.resumebuilderapp;

import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class TemplatePage extends AppCompatActivity implements View.OnClickListener{

    private Button Temp1,Temp2,Temp3,Temp4,Temp5,Temp6,Temp7,Temp8;
    private TextView Choose;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_template_page);

        Temp1 = (Button)findViewById(R.id.btn1);
        Temp2 = (Button)findViewById(R.id.btn2);
        Temp3 = (Button)findViewById(R.id.btn3);
        Temp4 = (Button)findViewById(R.id.btn4);
        Temp5 = (Button)findViewById(R.id.btn5);
        Temp6 = (Button)findViewById(R.id.btn6);
        Temp7 = (Button)findViewById(R.id.btn7);
        Temp8 = (Button)findViewById(R.id.btn8);

        Temp1.setOnClickListener(this);
        Temp2.setOnClickListener(this);
        Temp3.setOnClickListener(this);
        Temp4.setOnClickListener(this);
        Temp5.setOnClickListener(this);
        Temp6.setOnClickListener(this);
        Temp7.setOnClickListener(this);
        Temp8.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch(view.getId()) {
            case R.id.btn1:
                Intent intent1 = new Intent(TemplatePage.this, Template1.class);
                startActivity(intent1);
                break;
           case R.id.btn2:
               Intent intent2 = new Intent(TemplatePage.this, Template2.class);
               startActivity(intent2);
               break;
            case R.id.btn3:
                Intent intent3 = new Intent(TemplatePage.this, Template3.class);
                startActivity(intent3);
                break;
            case R.id.btn4:
                Intent intent4 = new Intent(TemplatePage.this, Template4.class);
                startActivity(intent4);
                break;
            case R.id.btn5:
                Intent intent5 = new Intent(TemplatePage.this, Template5.class);
                startActivity(intent5);
                break;
            case R.id.btn6:
                Intent intent6 = new Intent(TemplatePage.this, Template6.class);
                startActivity(intent6);
                break;
           /* case R.id.btn7:
                Intent intent7 = new Intent(TemplatePage.this, Temp7.class);
                startActivity(intent7);
                break;
            case R.id.btn8:
                Intent intent8 = new Intent(TemplatePage.this, Temp8.class);
                startActivity(intent8);
                break;
            default:
                Toast.makeText(this, "Not going anywhere !!!", Toast.LENGTH_LONG).show();
                break;*/
        }
    }

}
