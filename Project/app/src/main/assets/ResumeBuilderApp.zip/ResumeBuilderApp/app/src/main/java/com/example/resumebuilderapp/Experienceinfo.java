package com.example.resumebuilderapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Experienceinfo extends AppCompatActivity {
    private EditText company,from,to,role;
    private Button save;
    private DatabaseReference reff;
    private FirebaseAuth firebaseAuth;
    experience_info exi;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_experienceinfo);
        company=(EditText)findViewById(R.id.workplaceet);
        from=(EditText)findViewById(R.id.dojet);
        to=(EditText)findViewById(R.id.toet);
        role=(EditText)findViewById(R.id.roleet);
        save=(Button)findViewById(R.id.savebtn);
        exi=new experience_info();
        firebaseAuth=FirebaseAuth.getInstance();
        reff= FirebaseDatabase.getInstance().getReference(firebaseAuth.getUid());
        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean res=validate(new EditText[]{company,from,to,role});
                if(res==false){
                    Toast.makeText(Experienceinfo.this,"Please fill all details",Toast.LENGTH_LONG).show();
                }
                else {
                    exi.setCompany(company.getText().toString().trim());
                    exi.setFrom(from.getText().toString().trim());
                    exi.setTo(to.getText().toString().trim());
                    exi.setRole(role.getText().toString().trim());

                    reff.child("experienceinfo").setValue(exi);
                    Toast.makeText(Experienceinfo.this, "Saved Details", Toast.LENGTH_LONG).show();
                    startActivity(new Intent(Experienceinfo.this, SecondActivity.class));
                    Toast.makeText(Experienceinfo.this, "Enter Project Details", Toast.LENGTH_LONG).show();
                }
            }
        });


    }
        private boolean validate(EditText[] fields){
            for(int i = 0; i < fields.length; i++){
                EditText currentField = fields[i];
                if(currentField.getText().toString().length() <= 0){
                    return false;
                }
            }
            return true;
        }
}
