package com.example.resumebuilderapp;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import androidx.annotation.NonNull;


import android.os.Bundle;

public class RegistrationActivity extends AppCompatActivity {
    private EditText username,userpass,useremail;
    private Button register;

    private FirebaseAuth firebaseAuth;
    private ProgressDialog progressDialog;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);
        username=(EditText)findViewById(R.id.usernameet);
        useremail=(EditText)findViewById(R.id.emailtv);
        userpass=(EditText)findViewById(R.id.passwordet);

        register=(Button)findViewById(R.id.registerbtn);
        progressDialog=new ProgressDialog(this);
        firebaseAuth=firebaseAuth.getInstance();
        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(Check()){
                    String user_email=useremail.getText().toString().trim();
                    String user_pass=userpass.getText().toString().trim();
                    progressDialog.setMessage("Registering...");
                    progressDialog.show();
                    firebaseAuth.createUserWithEmailAndPassword(user_email,user_pass).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if(task.isSuccessful()){
                                progressDialog.dismiss();
                                Toast.makeText(RegistrationActivity.this,"Registration Successful",Toast.LENGTH_SHORT).show();
                                startActivity(new Intent(RegistrationActivity.this,SecondActivity.class));
                            }
                            else
                            {
                                Toast.makeText(RegistrationActivity.this,"Registration Failed",Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
                }
            }
        });
    }
    private Boolean Check()
    {
        Boolean result=false;
        String name=username.getText().toString();
        String email=useremail.getText().toString();
        String password=userpass.getText().toString();
        if(name.isEmpty()||email.isEmpty()||password.isEmpty()){
            Toast.makeText(this, "Please fill all details", Toast.LENGTH_SHORT).show();
        }
        else
        {
            result=true;
        }
        return result;
    }

}
