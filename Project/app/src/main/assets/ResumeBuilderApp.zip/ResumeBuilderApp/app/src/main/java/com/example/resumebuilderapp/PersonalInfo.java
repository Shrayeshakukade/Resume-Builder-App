package com.example.resumebuilderapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class PersonalInfo extends AppCompatActivity {
   private EditText dob,status,lang,nation;
   private Button save;
    private DatabaseReference reff;
    private FirebaseAuth firebaseAuth;
    personal_info pi;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_personal_info);
        dob=(EditText)findViewById(R.id.dobet);

        lang=(EditText)findViewById(R.id.languageet);
        nation=(EditText)findViewById(R.id.nationalityet);
        save=(Button)findViewById(R.id.btn_save);
        pi=new personal_info();
        firebaseAuth=FirebaseAuth.getInstance();
        reff= FirebaseDatabase.getInstance().getReference(firebaseAuth.getUid());
        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean res=validate(new EditText[]{dob,lang,nation});
                if(res==false){
                    Toast.makeText(PersonalInfo.this,"Please fill all details",Toast.LENGTH_LONG).show();
                }
                else {
                    pi.setDob(dob.getText().toString().trim());
                    pi.setLang(lang.getText().toString().trim());
                    pi.setNation(nation.getText().toString().trim());
                    reff.child("personalinfo").setValue(pi);
                    Toast.makeText(PersonalInfo.this, "Saved Details", Toast.LENGTH_LONG).show();
                    startActivity(new Intent(PersonalInfo.this, SecondActivity.class));
                    Toast.makeText(PersonalInfo.this, "Enter Education Details", Toast.LENGTH_LONG).show();
                }
            }
        });
    }
    private boolean validate(EditText[] fields){
        for(int i = 0; i < fields.length; i++){
            EditText currentField = fields[i];
            if(currentField.getText().toString().length() <= 0){
                return false;
            }
        }
        return true;
    }
}
